<?php
require_once('database.php');

   $_GET["name"]; 
   $_GET["address"]; 
   $_GET["phone_number"]; 
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
        Publisher entry
        </title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    
        <link rel="stylesheet" href="css/signup.css">
    </head>
    
    

    <body>
        
        <div class="container">
        <div class="row">
        <div class="col-sm-3">

      <center> <h1> Publisher EDIT</h1></center><br><br>
        <form action="" method="GET">
        name <input class="form-control" type="text" name="name" value="<?php echo $_GET['name']; ?>"/><br><br>
        address <input class="form-control" type="text" name="address" value="<?php echo $_GET['address']; ?>"/><br><br>
        phone_number <input class="form-control" type="text" name="phone_number" value="<?php echo $_GET['phone_number']; ?>"/><br>
          <input class="btn btn-primary" type="submit" name="submit" value="update">
        </form>
        </div>
        </div>
        </div>
        <?php
          if(isset($_GET['submit']))
          {
            $name = $_GET['name'];
            $address = $_GET['address'];
            $phone_number = $_GET['phone_number'];
            $conn=mysqli_connect("localhost","root","","library database");
            $query = "UPDATE publisher SET address='$address' , phone_number='$phone_number' WHERE name='$name'";
            $data = mysqli_query($conn,$query);
            echo "<script>alert('record updated')</script>";
    ?>
    <META http-equiv="Refresh" content="0; URL=http://localhost:3000/pdetails.php">
    <?php
          }
        
         ?>
         </body>
         </html>
