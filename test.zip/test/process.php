<?php
require_once('config.php');
?>

<?php


 if(isset($_POST)){
    $book_id = $_POST['book_id'];
    $date_out = $_POST['date_out'];
    $due_date = $_POST['due_date'];
    $card_no = $_POST['card_no'];

    $sql="INSERT INTO book_lending (book_id, date_out, due_date, card_no) VALUES (?,?,?,?)";
    $stmtinsert=$db->prepare($sql);
    $result= $stmtinsert->execute([$book_id, $date_out, $due_date, $card_no]);
    if($result){
        echo 'Sucessfully saved';
    }
    else{
        echo 'Errors';
    }
    
}
else{
    echo 'NO DATA';
}


?>