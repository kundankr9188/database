

function log() {
    var u = document.getElementById("user").value;
    var p = document.getElementById("pass").value; 

    if (u === "ashu" && p === "782000") {
             location.href = "http://localhost:3000/blending.php";
        }

    else
        alert("You are not a Administrator");
}
