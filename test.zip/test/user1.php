<?php
require_once('config.php');
?><!DOCTYPE html>
<html>
    <head>
        <title>
            library user
        </title>
    </head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="signup.css">

    <body>
        
        <div class="sign">
            <form action="user1.php" method="POST">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3">
                    <h3> LIBRARY USERS</h3>
                
                    <hr class="nb-3">
                    <label for="name"><b>NAME</b></label>
                    <input class="form-control" type="text" id="name" name="name" required placeholder="enter your name">

                    <label for="phno"><b>PHONE_NO</b></label>
                    <input class="form-control" type="text" id="ph_no" name="ph_no" required placeholder="enter the phno">

                    <label for="email_id"><b>EMAIL_ID</b></label>
                    <input class="form-control" type="email" id="email_id" name="email_id" required placeholder="enter your email id">

                    <label for="address"><b>ADDRESS</b></label>
                    <input class="form-control" type="text" id="address" name="address" required placeholder="enter your address">

                    <hr class="nb-3">

                    <input class="btn btn-primary" type="submit" id="register" name="Create" value="SUBMIT">
                         </div>
                </div>
                </div>
                <center><button class="button"><a href="http://localhost:3000/viewuser.php">View User's List</a></button></center>

            </form>
        </div>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

        <script type="text/javascript">
        $(function(){
		$('#register').click(function(e){

			var valid = this.form.checkValidity();

			if(valid){

            var name	    = $('#name').val();
			var ph_no	= $('#ph_no').val();
			var email_id 	= $('#email_id').val();
			var address 	= $('#address').val();
            
			

				e.preventDefault();	

				$.ajax({
					type: 'POST',
					url: 'process1.php',
					data: {name : name, ph_no: ph_no,email_id: email_id,address: address},
					success: function(data){
					Swal.fire({
								'title': 'Card Number Generated',
								'text': data,
								'type': 'success'
								}).then(ok=> {
   if (ok) {
    window.location.href = "test.html";
  }
});
							
					},
					error: function(data){
						Swal.fire({
								'title': 'Errors',
								'text': 'There were errors while saving the data.',
								'type': 'error'
								})
					}
				});

				
			}else{
				
			}

			



		});		

		
	});
        </script>
    </body>
</html>