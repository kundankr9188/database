<?php
include_once 'database.php';
$result = mysqli_query($conn,"SELECT * FROM book_lending");
?>
<button class="button"><a href="test.html">back to main</a></button>
<!DOCTYPE html>
<html>
 <head>
 <title>Library Database</title>
 </head>
<body>
<style>
    table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;

}

tr:nth-child(even) {
    background-color: white;
}
</style>
<?php
if (mysqli_num_rows($result) > 0) {
?>
  <table>
  <tr>
    <td>book_id</td>
    <td>card_no</td>
    <td>date_out</td>    
    <td>due_date</td>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
      <td><?php echo $row["book_id"]; ?></td>
      <td><?php echo $row["card_no"]; ?></td>
      <td><?php echo $row["date_out"]; ?></td>
      <td><?php echo $row["due_date"]; ?></td>

</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>

 </body>
</html>