<?php
include_once 'database.php';
include_once 'index3.php';
?>
<br>
<button class="button"><a href="test.html">back to main</a></button>
<?php
$result = mysqli_query($conn,"SELECT * FROM publisher");
?>
<!DOCTYPE html>
<html>
 <head>
 <title>Library Database</title>
 </head>
<body>
<style>
    table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;

}

tr:nth-child(even) {
    background-color: white;
}
</style>
<?php
if (mysqli_num_rows($result) > 0) {
?>
  <table>
  <tr>
    <td>name</td>
    <td>address</td>
    <td>phone_number</td>
    <td>Options</td>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
      <td><?php echo $row["name"]; ?></td>
      <td><?php echo $row["address"]; ?></td>
      <td><?php echo $row["phone_number"]; ?></td>
      <td style="text-align:center; width:150px">
        <span><a href="pupdate.php?name=<?php echo $row['name']; ?> && address=<?php echo $row['address']; ?> && phone_number=<?php echo $row['phone_number']; ?>" value="Edit">Update</a></span>
        <span><a href="pdel.php?name=<?php echo $row['name']; ?> " onclick="return checkdelete()" value="Delete">Delete</a></span>
      </td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>

 </body>
</html>