<?php
require_once('database.php');
$name=$_GET["name"];
$conn=mysqli_connect("localhost","root","","library database");
$query = "DELETE FROM publisher WHERE name='$name'";

$data = mysqli_query($conn,$query);
if($data)
{
    echo "<script>alert('record deleted')</script>";
    ?>
    <META http-equiv="Refresh" content="0; URL=http://localhost:3000/pdetails.php">
    <?php
}
else{
    echo "<font color='red'>sorry delete process failed";
}
?>