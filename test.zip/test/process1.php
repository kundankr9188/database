<?php
require_once('config.php');
?>

<?php


 if(isset($_POST)){
    $name = $_POST['name'];
    $ph_no = $_POST['ph_no'];
    $email_id = $_POST['email_id'];
    $address = $_POST['address'];

    $sql="INSERT INTO library_users (name, ph_no, email_id, address) VALUES (?,?,?,?)";
    $stmtinsert=$db->prepare($sql);
    $result= $stmtinsert->execute([$name, $ph_no, $email_id, $address]);
    if($result){
        echo 'Sucessfully saved';
    }
    else{
        echo 'Errors';
    }
    
}
else{
    echo 'NO DATA';
}


?>