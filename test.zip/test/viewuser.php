<?php
include_once 'database.php';
$result = mysqli_query($conn,"SELECT * FROM library_users");
?>
<button class="button"><a href="test.html">back to main</a></button>
<!DOCTYPE html>
<html>
 <head>
 <title>Library Database</title>
 </head>
<body>
<style>
    table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;

}

tr:nth-child(even) {
    background-color: white;
}
</style>
<?php
if (mysqli_num_rows($result) > 0) {
?>
  <table>
  <tr>
    <td>name</td>
    <td>card_no</td>
    <td>ph_no</td>    
    <td>email_id</td>
    <td>address</td>

  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
      <td><?php echo $row["name"]; ?></td>
      <td><?php echo $row["card_no"]; ?></td>
      <td><?php echo $row["ph_no"]; ?></td>
      <td><?php echo $row["email_id"]; ?></td>
      <td><?php echo $row["address"]; ?></td>


</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>

 </body>
</html>